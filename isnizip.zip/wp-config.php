<?php
define( 'WP_CACHE', true );


/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'kotakuid_wp96' );

/** Database username */
define( 'DB_USER', 'kotakuid_wp96' );

/** Database password */
define( 'DB_PASSWORD', 'r9S5Np))13' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '8mzwjmyiwreklajenxekmtz5x0xdknjqqk8bt2pbnc6bxwwuu2p6dxfgvrak0zv9' );
define( 'SECURE_AUTH_KEY',  '4t5xfgirvoybjgnjnetcrsj3z189a9tc5xa0gfirhchwhuhsshifsk5iuyjlzvcn' );
define( 'LOGGED_IN_KEY',    'seemrbrt5frlztdvo5xfdcu1hhhku8dg4lwrbvzm8jkzcfig4vzyvxuerwtiljdb' );
define( 'NONCE_KEY',        'yghij4zenwznsmiycfgukhdk2hlxqd8r7q8q2k3k66j60a6varbdzimysnei8ock' );
define( 'AUTH_SALT',        'cucn3rdmxjywxh5bbbgxgfmgpv0c4hyydlhveuthoawi4uhm7hfy3klnax9mxkmw' );
define( 'SECURE_AUTH_SALT', 'cv0mvga9upjvmtdivmnc7mvpns9enfx7wm3jypi7tqasmuyfruzqvmltyuhgmfoy' );
define( 'LOGGED_IN_SALT',   'b4q8xmsw5wockmccr7xrn1w0mfm9yrxe6g3ku0hb67mwhmqdygdixhrstpowyscg' );
define( 'NONCE_SALT',       '0u8mpcqa0xwkh6n2yxx4clxjp8jvatzjtzisrv9mhdnxnlmo1v7dgevfp4dgqzxh' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpjm_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
